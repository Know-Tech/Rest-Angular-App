import {Employee} from './employee_model';

export const EMPLOYEES: Employee[] = [
  { employeeid:11,employeename:'aswathi',email:'aswathi.niit@gmail.com',pass:'aswa',age:25,mobile:'9685321471',gender:'female',qualification:'IT' },
 {employeeid:12,employeename:'bala',email:'bala@gmail.com',pass:'bala',age:24,mobile:'9876654123',gender:'male',qualification:'IT' }
 
];